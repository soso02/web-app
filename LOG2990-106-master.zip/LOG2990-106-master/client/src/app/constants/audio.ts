export const FADE_OUT_PERIOD = 100;
export const FADE_OUT_VOLUME_CHANGE = 0.1;
export const AUDIO_PATH = './assets/audio/';
export const PANIC_SOUNDS = [
    'sims4-enraged.mp3',
    'sims4-hysterical.mp3',
    'sims4-mortified.mp3',
    'sims4-very-embarrassed.mp3',
    'sims4-very-tense.mp3',
];
export const MENU_SOUNDS = [];
