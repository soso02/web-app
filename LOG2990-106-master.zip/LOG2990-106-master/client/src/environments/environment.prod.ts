export const environment = {
    production: true,
    serverBaseUrl: 'http://ec2-99-79-33-118.ca-central-1.compute.amazonaws.com:3000',
    serverGamesUrl: 'http://ec2-99-79-33-118.ca-central-1.compute.amazonaws.com:3000/api/games',
    serverAdminUrl: 'http://ec2-99-79-33-118.ca-central-1.compute.amazonaws.com:3000/api/admin',
};
