export interface TimerConfiguration {
    isQuestionTransition?: boolean;
    isPanicModeEnabled?: boolean;
    isInputInactivityCountdown?: boolean;
}
