import { Route } from '../client/src/app/constants/enums';

export enum GameMode {
    Testing = Route.InGame,
    RealGame = Route.Lobby,
}
